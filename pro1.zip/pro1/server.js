const express = require('express');
const app = express();
const PORT = 3000;

const produtosRoutes = require('./src/routes/produtosRoute');
app.use(express.json());


app.get('/', (req, res) => {
    res.send('API CRUD completa com sucesso');  
});
app.use('/api/produtos', produtosRoutes);
app.use('/produtos', produtosRoutes);

app.listen(PORT, () => {
    console.log(`Server rodando em  http://localhost:${PORT}`);
});
