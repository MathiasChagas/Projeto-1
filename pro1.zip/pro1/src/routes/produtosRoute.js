const express = require('express');
const router = express.Router();
const produtosController = require('../controllers/produtosController');

router.get('/', produtosController.listar);
router.get('/', produtosController.buscarPorId);
module.exports = router;
