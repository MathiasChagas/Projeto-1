const produtos = [
    {id: 1, nome: 'produto a'}
];

module.exports = {
    listar: (req, res) => {
        res.json(produtos);
    },
    buscarPorId: (req, res) => {
        const id = Number(req.params.id);
        const produto = produtos.find(p =>p.id === id);
        if (produto) {
            return res.status(404).json({erro:'Produto não encontrado' });
        } 
        res.json(produto);
    }
};
