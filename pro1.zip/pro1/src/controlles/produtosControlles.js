const produtos = require('../models/produtosModel');

module.exports={
    async listar(req, res){
        try{
            const produtos = await Produto.listar();
            res.json(produtos);
        }catch(erro){
            res.status(500).json({ erro: 'Erro ao listar os produtos' });
        }
    },
    async buscarPorId (req, res){
        try{
            const id = Number(req.params.id);
            const produto = await Produto.buscarPorId(id);

            if(!produto){
                return res.status(404).json({ erro: 'Produto não encontrado' });
            }
            res.json(produto);
        }catch(erro){
            res.status(500).json({ erro: 'Erro ao buscar o produto' });
        }
    },



    async criar(req, res){
        try{
            const { nome,preço } = req.body;

            if(!nome || !preço){
                return res.status(400).json({ erro: 'Nome e preço são obrigatórios' });
            }
            const novo = await Produto.criar({ nome, preco });
            res.status(201).json({mensagem: "produtto criado com sucesso",});
        }catch(erro){
            res.status(500).json({ erro: 'Erro ao criar o produto' });
    }
},
  
     async atualizar(req, res){
                try{
                    const id = Number(req.params.id);
                    const { nome, preço } = req.body;

                    const atualizado = await Produto.atualizar(id,  nome, preço );

                    if(!atualizado){
                        return res.status(404).json({ erro: 'Produto não encontrado' });
                    }

                    res.json({ mensagem: 'Produto atualizado com sucesso' });
                }catch(erro){
                    res.status(500).json({ erro: 'Erro ao atualizar o produto' });
                }
            },
            async deletar(req, res){
                try{
                   const id = req.params.id;
                   const deletar = await Produto.deletar(id);

                   if(!deletar){
                      return res.status(404).json({ Erro: 'produto não deletado'})
                   }
                   res.json({ mensagem: 'produto deletado'})
                }catch(erro){
                    res.status(500).json({èrro: 'erro ao deletar'})
                }
            }
        }